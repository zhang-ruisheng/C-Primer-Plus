// exercise03.h
// function prototypes for exercise 3

void set_mode(int *mode);
void get_info(int mode, double *distance, double *fuel);
void show_info(int mode, double distance, double fuel);