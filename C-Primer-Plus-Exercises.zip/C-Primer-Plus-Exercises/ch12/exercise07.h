// header file for exercise 7

int rolldice(int dice, int sides);

void dicerolls(int sets, int dice, int sides);