// exercise02.h

void set_mode(int mode);
void get_info(void);
void show_info(void);