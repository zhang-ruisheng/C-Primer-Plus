// binary_search.h -- header file for binary search implementation

#ifndef BINARY_SEARCH_H_
#define BINARY_SEARCH_H_ 1

int binarysearch(int * arr, int arr_size, int target);

#endif

