Chapter 8: Character Input/Output and Input Validation
======================================================