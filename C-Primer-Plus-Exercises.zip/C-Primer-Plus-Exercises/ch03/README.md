Chapter 3: Data and C
======================

Introduction to basic C data types.