// C Primer Plus
// Chapter 16 Exercise 1:

// Start developing a header file of preprocessor definitions that you want
// to use.

#ifndef EXERCISE01_H_
#define EXERCISE01_H_

#include <stdio.h>

#define CLEARINPUT while (getchar() != '\n') continue

#endif